package the.coyote.cdc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CdcApplicationTests {

	@Test
	void contextLoads() {
	}

}
